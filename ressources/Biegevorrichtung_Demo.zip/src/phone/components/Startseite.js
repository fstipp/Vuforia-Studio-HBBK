// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


var explosionsansicht  = false;


$scope.press_explosion = function () {
    function startExplosion(direction) {
    var counter = 0
    function animate() {
      if (counter < 360) {
        	counter += 1
        // Hier werden alle Teile aufgeführt, welche bewegt werden sollen
        
        // Buchse + Hebel
       	$scope.view.wdg['modelItem-1'].z += direction * 0.0003;
        $scope.view.wdg['modelItem-2'].z += direction * 0.0003;
        $scope.view.wdg['modelItem-3'].z += direction * 0.0003;
        
        // Bolzen
        $scope.view.wdg['modelItem-4'].z += direction * 0.00055;
        
        // usw.
        $scope.view.wdg['modelItem-5'].z += direction * 0.0002;
        $scope.view.wdg['modelItem-6'].z += direction * 0.00025;
        $scope.view.wdg['modelItem-7'].z += direction * 0.0002;
        
        $scope.view.wdg['modelItem-8'].z += direction * 0.00019;
        $scope.view.wdg['modelItem-9'].z += direction * 0.00025;
        
        $scope.view.wdg['modelItem-10'].z += direction * 0.0002;
        
        $scope.view.wdg['modelItem-11'].z += direction * 0.00015;
        
        $scope.view.wdg['modelItem-12'].z += direction * 0.0001;
        $scope.view.wdg['modelItem-13'].z += direction * 0.0001;
        
        $scope.view.wdg['modelItem-14'].z += direction * 0.00003;
        
        
      
        $timeout(animate, 5);
      } 
    }
    animate();
    }
      
    explosionsansicht = !explosionsansicht;
    startExplosion(explosionsansicht ? 1 : -1)
  };